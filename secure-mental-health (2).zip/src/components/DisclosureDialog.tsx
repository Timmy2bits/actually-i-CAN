import React from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle, Shield, Clock, Phone } from 'lucide-react';

interface DisclosureDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function DisclosureDialog({ open, onOpenChange }: DisclosureDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto bg-gray-900 border-red-800">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-red-400">
            <Shield className="w-5 h-5" />
            Privacy & Safety Disclosure
          </DialogTitle>
          <DialogDescription className="text-gray-300">
            Important information about your privacy and safety
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6">
          <Alert className="bg-red-950 border-red-800">
            <Shield className="h-4 w-4 text-red-400" />
            <AlertDescription className="text-gray-200">
              <strong>Encryption & Security:</strong> All communications are encrypted, but no system is 100% secure. There's always a small chance others could access your data.
            </AlertDescription>
          </Alert>

          <Alert className="bg-red-950 border-red-800">
            <AlertTriangle className="h-4 w-4 text-red-400" />
            <AlertDescription className="text-gray-200">
              <strong>Mental Health Disclosure:</strong> Be careful about what personal mental health information you share. Only share what you're comfortable with potentially being seen by others.
            </AlertDescription>
          </Alert>

          <Alert className="bg-red-950 border-red-800">
            <Phone className="h-4 w-4 text-red-400" />
            <AlertDescription className="text-gray-200">
              <strong>Not an Emergency Service:</strong> This is NOT an emergency hotline. If you're having a mental health emergency, please call 988 (Suicide & Crisis Lifeline) or your local emergency services.
            </AlertDescription>
          </Alert>

          <Alert className="bg-red-950 border-red-800">
            <Clock className="h-4 w-4 text-red-400" />
            <AlertDescription className="text-gray-200">
              <strong>Response Time:</strong> I will respond as soon as possible, typically within 24 hours. For urgent matters, please use appropriate emergency services.
            </AlertDescription>
          </Alert>

          <div className="text-sm text-gray-400">
            <p>By using this service, you acknowledge that you understand these terms and agree to use this platform responsibly.</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}