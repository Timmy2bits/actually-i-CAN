import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Lock, User } from 'lucide-react';

interface MessageItemProps {
  message: {
    id: string;
    content: string;
    timestamp: Date;
    isEncrypted: boolean;
    sender: string;
  };
}

const MessageItem: React.FC<MessageItemProps> = ({ message }) => {
  return (
    <Card className="mb-3 bg-gradient-to-r from-blue-50 to-purple-50 border-l-4 border-l-blue-500 hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-2">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-blue-600" />
            <span className="font-medium text-blue-800">{message.sender}</span>
            {message.isEncrypted && (
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                <Lock className="w-3 h-3 mr-1" />
                Encrypted
              </Badge>
            )}
          </div>
          <span className="text-xs text-gray-500">
            {message.timestamp.toLocaleTimeString()}
          </span>
        </div>
        <p className="text-gray-700">{message.content}</p>
      </CardContent>
    </Card>
  );
};

export default MessageItem;