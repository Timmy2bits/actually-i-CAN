import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { FileText, Save, X } from 'lucide-react';

interface Worksheet {
  id: string;
  title: string;
  category: string;
  lastModified: Date;
  entries: number;
  content?: string;
  notes?: string;
}

interface WorksheetFormProps {
  onSave: (worksheet: Worksheet) => void;
  onCancel: () => void;
  initialData?: Worksheet | null;
}

const WorksheetForm: React.FC<WorksheetFormProps> = ({ onSave, onCancel, initialData }) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [content, setContent] = useState('');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (initialData) {
      setTitle(initialData.title);
      setCategory(initialData.category);
      setContent(initialData.content || '');
      setNotes(initialData.notes || '');
    }
  }, [initialData]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim() || !category.trim()) {
      return;
    }

    const worksheet: Worksheet = {
      id: initialData?.id || Date.now().toString(),
      title: title.trim(),
      category: category.trim(),
      content: content.trim(),
      notes: notes.trim(),
      lastModified: new Date(),
      entries: initialData?.entries || 0
    };

    onSave(worksheet);
  };

  const categories = [
    'Mood Tracking',
    'Anxiety Management',
    'Depression Support',
    'Coping Skills',
    'Positive Psychology',
    'Self-Care',
    'Goal Setting',
    'Mindfulness',
    'Journal',
    'Other'
  ];

  return (
    <Card className="bg-black/40 border-red-500 text-white">
      <CardHeader>
        <CardTitle className="text-red-400 flex items-center gap-2">
          <FileText className="w-5 h-5" />
          {initialData ? 'Edit Worksheet' : 'Create New Worksheet'}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title" className="text-red-200">
              Worksheet Title *
            </Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter worksheet title..."
              className="bg-gray-800 border-red-500 text-white placeholder-gray-400"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="category" className="text-red-200">
              Category *
            </Label>
            <Select value={category} onValueChange={setCategory} required>
              <SelectTrigger className="bg-gray-800 border-red-500 text-white">
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-red-500">
                {categories.map((cat) => (
                  <SelectItem key={cat} value={cat} className="text-white hover:bg-red-600">
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="content" className="text-red-200">
              Description
            </Label>
            <Textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Describe what this worksheet is for..."
              className="bg-gray-800 border-red-500 text-white placeholder-gray-400 min-h-[100px]"
              rows={4}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes" className="text-red-200">
              Personal Notes
            </Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add any personal notes or reminders..."
              className="bg-gray-800 border-red-500 text-white placeholder-gray-400"
              rows={3}
            />
          </div>

          <div className="flex gap-3 pt-4">
            <Button
              type="submit"
              className="bg-red-600 hover:bg-red-700 text-white flex-1"
              disabled={!title.trim() || !category.trim()}
            >
              <Save className="w-4 h-4 mr-2" />
              {initialData ? 'Update Worksheet' : 'Create Worksheet'}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              className="border-red-500 text-red-300 hover:bg-red-600 hover:text-white"
            >
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default WorksheetForm;