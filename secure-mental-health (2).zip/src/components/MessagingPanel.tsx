import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { MessageCircle } from 'lucide-react';
import MessageItem from './MessageItem';
import MessageInput from './MessageInput';

interface Message {
  id: string;
  content: string;
  timestamp: Date;
  isEncrypted: boolean;
  sender: string;
}

const MessagingPanel: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: 'Welcome to your secure messaging space. All messages are encrypted for your privacy.',
      timestamp: new Date(),
      isEncrypted: true,
      sender: 'System'
    }
  ]);

  const handleSendMessage = (content: string, isEncrypted: boolean) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      content,
      timestamp: new Date(),
      isEncrypted,
      sender: 'You'
    };
    setMessages(prev => [...prev, newMessage]);
  };

  return (
    <div className="h-full flex flex-col">
      <Card className="flex-1 bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200">
        <CardHeader>
          <CardTitle className="text-blue-800 flex items-center gap-2">
            <MessageCircle className="w-5 h-5" />
            Secure Messages
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1">
          <ScrollArea className="h-[400px] pr-4">
            {messages.map((message) => (
              <MessageItem key={message.id} message={message} />
            ))}
          </ScrollArea>
        </CardContent>
      </Card>
      <div className="mt-4">
        <MessageInput onSendMessage={handleSendMessage} />
      </div>
    </div>
  );
};

export default MessagingPanel;