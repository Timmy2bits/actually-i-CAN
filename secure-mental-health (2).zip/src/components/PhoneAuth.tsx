import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';

interface PhoneAuthProps {
  onAuthSuccess: (userId: string) => void;
}

export const PhoneAuth: React.FC<PhoneAuthProps> = ({ onAuthSuccess }) => {
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [step, setStep] = useState<'phone' | 'verify'>('phone');
  const [loading, setLoading] = useState(false);

  const sendVerification = async () => {
    if (!phone.trim()) {
      toast.error('Please enter a phone number');
      return;
    }

    setLoading(true);
    try {
      // For demo purposes, we'll simulate sending SMS and always succeed
      // In production, this would call the actual SMS service
      await new Promise(resolve => setTimeout(resolve, 1000));
      setStep('verify');
      toast.success('Verification code sent! Use demo code: 123456');
    } catch (error) {
      toast.error('Error sending verification');
    } finally {
      setLoading(false);
    }
  };

  const verifyCode = async () => {
    if (!code.trim()) {
      toast.error('Please enter the verification code');
      return;
    }

    setLoading(true);
    try {
      // Demo verification - accept 123456 as valid code
      if (code === '123456') {
        const userId = `user_${phone.replace(/\D/g, '')}_${Date.now()}`;
        toast.success('Phone verified successfully!');
        onAuthSuccess(userId);
      } else {
        toast.error('Invalid verification code. Use: 123456');
      }
    } catch (error) {
      toast.error('Error verifying code');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto bg-gray-900 border-red-800">
      <CardHeader>
        <CardTitle className="text-red-400">Secure Access</CardTitle>
        <CardDescription className="text-gray-300">
          {step === 'phone' ? 'Enter your phone number to get started' : 'Enter the verification code sent to your phone'}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {step === 'phone' ? (
          <>
            <div className="space-y-2">
              <Label htmlFor="phone" className="text-gray-200">Phone Number</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="+1 (555) 123-4567"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="bg-gray-800 border-red-700 text-gray-200 placeholder-gray-400"
              />
            </div>
            <Button 
              onClick={sendVerification} 
              disabled={loading} 
              className="w-full bg-red-800 hover:bg-red-700 text-white"
            >
              {loading ? 'Sending...' : 'Send Verification Code'}
            </Button>
          </>
        ) : (
          <>
            <div className="space-y-2">
              <Label htmlFor="code" className="text-gray-200">Verification Code</Label>
              <Input
                id="code"
                type="text"
                placeholder="123456"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                maxLength={6}
                className="bg-gray-800 border-red-700 text-gray-200 placeholder-gray-400"
              />
            </div>
            <Button 
              onClick={verifyCode} 
              disabled={loading} 
              className="w-full bg-red-800 hover:bg-red-700 text-white"
            >
              {loading ? 'Verifying...' : 'Verify Code'}
            </Button>
            <Button 
              variant="outline" 
              onClick={() => setStep('phone')} 
              className="w-full bg-gray-800 border-red-700 text-red-300 hover:bg-red-900/40"
            >
              Change Phone Number
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  );
};