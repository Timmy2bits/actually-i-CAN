import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Send, Lock } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

interface MessageInputProps {
  onSendMessage: (content: string, isEncrypted: boolean) => void;
}

const MessageInput: React.FC<MessageInputProps> = ({ onSendMessage }) => {
  const [message, setMessage] = useState('');
  const [isEncrypted, setIsEncrypted] = useState(true);

  const handleSend = () => {
    if (message.trim()) {
      onSendMessage(message, isEncrypted);
      setMessage('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <Card className="bg-gradient-to-r from-indigo-50 to-cyan-50 border-2 border-indigo-200">
      <CardContent className="p-4">
        <div className="flex items-center gap-3 mb-3">
          <Switch 
            id="encryption" 
            checked={isEncrypted} 
            onCheckedChange={setIsEncrypted}
            className="data-[state=checked]:bg-green-600"
          />
          <Label htmlFor="encryption" className="flex items-center gap-2 font-medium">
            <Lock className="w-4 h-4" />
            Encrypt Message
          </Label>
        </div>
        <div className="flex gap-2">
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type your secure message..."
            className="flex-1 min-h-[60px] resize-none border-indigo-200 focus:border-indigo-400"
          />
          <Button 
            onClick={handleSend}
            disabled={!message.trim()}
            className="bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-700 hover:to-cyan-700 px-6"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default MessageInput;