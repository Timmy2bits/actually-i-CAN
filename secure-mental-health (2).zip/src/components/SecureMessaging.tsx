import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { Send, MessageCircle } from 'lucide-react';

interface Message {
  id: string;
  content: string;
  is_from_user: boolean;
  created_at: string;
}

interface SecureMessagingProps {
  userId: string;
}

export const SecureMessaging: React.FC<SecureMessagingProps> = ({ userId }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadMessages();
    const subscription = supabase
      .channel('messages')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'messages', filter: `user_id=eq.${userId}` },
        () => loadMessages()
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [userId]);

  const loadMessages = async () => {
    try {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: true });

      if (error) throw error;
      setMessages(data || []);
    } catch (error) {
      console.error('Error loading messages:', error);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim()) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('messages')
        .insert({
          user_id: userId,
          content: newMessage,
          is_from_user: true
        });

      if (error) throw error;

      // Send notification to therapist via edge function
      try {
        await fetch('https://vvedufkksgfcfvhbirgm.supabase.co/functions/v1/81710094-94a9-471d-bc85-517b24c6a784', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId, message: newMessage })
        });
      } catch (fnError) {
        console.log('Function call failed, but message saved');
      }

      setNewMessage('');
      toast.success('Message sent securely');
    } catch (error) {
      toast.error('Failed to send message');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="h-[600px] flex flex-col bg-gray-900 border-red-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-red-400">
          <MessageCircle className="w-5 h-5" />
          Secure Messaging
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col">
        <ScrollArea className="flex-1 mb-4 p-4 border border-red-700 rounded bg-gray-800">
          {messages.length === 0 ? (
            <p className="text-center text-gray-400">No messages yet. Start a conversation!</p>
          ) : (
            messages.map((message) => (
              <div
                key={message.id}
                className={`mb-4 p-3 rounded-lg max-w-[80%] ${
                  message.is_from_user
                    ? 'ml-auto bg-red-800 text-white'
                    : 'mr-auto bg-gray-700 text-gray-100'
                }`}
              >
                <p className="text-sm">{message.content}</p>
                <p className="text-xs opacity-70 mt-1">
                  {new Date(message.created_at).toLocaleString()}
                </p>
              </div>
            ))
          )}
        </ScrollArea>
        <div className="flex gap-2">
          <Textarea
            placeholder="Type your message here..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            className="flex-1 bg-gray-800 border-red-700 text-gray-200 placeholder-gray-400"
            rows={3}
          />
          <Button 
            onClick={sendMessage} 
            disabled={loading || !newMessage.trim()}
            className="bg-red-800 hover:bg-red-700 text-white"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};