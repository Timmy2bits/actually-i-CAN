import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BookOpen, Video, Headphones, ExternalLink, Search, Phone } from 'lucide-react';

interface Resource {
  id: string;
  title: string;
  description: string;
  type: 'article' | 'video' | 'audio' | 'crisis';
  url?: string;
  category: string;
}

const ResourceLibrary: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const resources: Resource[] = [
    {
      id: '1',
      title: 'Crisis Text Line',
      description: 'Text HOME to 741741 for free, 24/7 crisis support',
      type: 'crisis',
      category: 'Emergency'
    },
    {
      id: '2',
      title: 'National Suicide Prevention Lifeline',
      description: 'Call 988 for immediate help and support',
      type: 'crisis',
      category: 'Emergency'
    },
    {
      id: '3',
      title: 'Understanding Anxiety',
      description: 'Learn about anxiety symptoms and coping strategies',
      type: 'article',
      url: 'https://www.nimh.nih.gov/health/topics/anxiety-disorders',
      category: 'Anxiety'
    },
    {
      id: '4',
      title: 'Depression Self-Help Guide',
      description: 'Practical tips for managing depression symptoms',
      type: 'article',
      url: 'https://www.helpguide.org/articles/depression/coping-with-depression.htm',
      category: 'Depression'
    },
    {
      id: '5',
      title: 'Mindfulness Meditation',
      description: '10-minute guided meditation for stress relief',
      type: 'audio',
      url: 'https://www.headspace.com',
      category: 'Mindfulness'
    },
    {
      id: '6',
      title: 'Breathing Exercises',
      description: 'Simple breathing techniques for anxiety relief',
      type: 'video',
      url: 'https://www.youtube.com/watch?v=YRPh_GaiL8s',
      category: 'Coping Skills'
    },
    {
      id: '7',
      title: 'Sleep Hygiene Tips',
      description: 'Improve your sleep quality for better mental health',
      type: 'article',
      url: 'https://www.sleepfoundation.org/sleep-hygiene',
      category: 'Self-Care'
    },
    {
      id: '8',
      title: 'Addiction Recovery Support',
      description: 'Resources and support for addiction recovery',
      type: 'article',
      url: 'https://addiction--recovery.blogspot.com/?m=1',
      category: 'Addiction'
    }
  ];

  const filteredResources = resources.filter(resource =>
    resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    resource.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    resource.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getResourceIcon = (type: string) => {
    switch (type) {
      case 'article': return <BookOpen className="w-4 h-4" />;
      case 'video': return <Video className="w-4 h-4" />;
      case 'audio': return <Headphones className="w-4 h-4" />;
      case 'crisis': return <Phone className="w-4 h-4" />;
      default: return <BookOpen className="w-4 h-4" />;
    }
  };

  const getResourcesByType = (type: string) => {
    return filteredResources.filter(resource => resource.type === type);
  };

  const ResourceCard: React.FC<{ resource: Resource }> = ({ resource }) => (
    <Card className="bg-gray-900/50 border-red-500/30 text-white hover:border-red-400 transition-colors">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-2">
          <div className="flex items-center gap-2">
            {getResourceIcon(resource.type)}
            <h3 className="font-semibold text-red-200">{resource.title}</h3>
          </div>
          <Badge variant="outline" className="border-red-500 text-red-300 text-xs">
            {resource.category}
          </Badge>
        </div>
        <p className="text-sm text-gray-300 mb-3">{resource.description}</p>
        {resource.url ? (
          <Button
            size="sm"
            variant="outline"
            className="border-red-500 text-red-300 hover:bg-red-600 hover:text-white"
            onClick={() => window.open(resource.url, '_blank')}
          >
            <ExternalLink className="w-3 h-3 mr-1" />
            Open Resource
          </Button>
        ) : (
          <Badge className="bg-red-600 text-white">
            {resource.type === 'crisis' ? 'Emergency Contact' : 'Contact Info'}
          </Badge>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      {/* Search */}
      <Card className="bg-black/40 border-red-500">
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-red-400 w-4 h-4" />
            <Input
              placeholder="Search resources..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-gray-800 border-red-500 text-white placeholder-gray-400"
            />
          </div>
        </CardContent>
      </Card>

      {/* Crisis Resources */}
      <Card className="bg-red-900/20 border-red-400">
        <CardHeader>
          <CardTitle className="text-red-300 flex items-center gap-2">
            <Phone className="w-5 h-5" />
            Crisis & Emergency Resources
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            {getResourcesByType('crisis').map(resource => (
              <ResourceCard key={resource.id} resource={resource} />
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Other Resources */}
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-black/60 border border-red-500">
          <TabsTrigger value="all" className="text-red-200 data-[state=active]:bg-red-600">
            All Resources
          </TabsTrigger>
          <TabsTrigger value="article" className="text-red-200 data-[state=active]:bg-red-600">
            Articles
          </TabsTrigger>
          <TabsTrigger value="video" className="text-red-200 data-[state=active]:bg-red-600">
            Videos
          </TabsTrigger>
          <TabsTrigger value="audio" className="text-red-200 data-[state=active]:bg-red-600">
            Audio
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredResources.filter(r => r.type !== 'crisis').map(resource => (
              <ResourceCard key={resource.id} resource={resource} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="article" className="mt-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {getResourcesByType('article').map(resource => (
              <ResourceCard key={resource.id} resource={resource} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="video" className="mt-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {getResourcesByType('video').map(resource => (
              <ResourceCard key={resource.id} resource={resource} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="audio" className="mt-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {getResourcesByType('audio').map(resource => (
              <ResourceCard key={resource.id} resource={resource} />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ResourceLibrary;