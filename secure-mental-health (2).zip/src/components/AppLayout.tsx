import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MessageCircle, FileText, Shield, Heart, BarChart3, BookOpen, ExternalLink } from 'lucide-react';
import MessagingPanel from './MessagingPanel';
import WorksheetPanel from './WorksheetPanel';
import MoodTracker from './MoodTracker';
import ResourceLibrary from './ResourceLibrary';
import Logo from './Logo';
import DisclosureDialog from './DisclosureDialog';

const AppLayout: React.FC = () => {
  const [activeTab, setActiveTab] = useState('worksheets');

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-red-900 to-black p-4">
      <div className="max-w-7xl mx-auto">
        <Card className="mb-6 bg-gradient-to-r from-red-600 to-black text-white border-red-500 shadow-xl">
          <CardHeader>
            <div className="flex items-center justify-between">
              <Logo />
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="border-red-400 text-red-100 hover:bg-red-700"
                  onClick={() => window.open('https://addiction--recovery.blogspot.com/?m=1', '_blank')}
                >
                  <ExternalLink className="w-4 h-4 mr-1" />
                  Blog
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="border-red-400 text-red-100 hover:bg-red-700"
                  onClick={() => window.open('https://www.twelch.com/', '_blank')}
                >
                  <ExternalLink className="w-4 h-4 mr-1" />
                  Website
                </Button>
                <DisclosureDialog />
              </div>
            </div>
            <p className="text-red-100 mt-2">
              Your private, secure space for mental health tracking and communication
            </p>
          </CardHeader>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6 bg-black/80 backdrop-blur-sm border-2 border-red-500">
            <TabsTrigger 
              value="messages" 
              className="flex items-center gap-2 text-red-100 data-[state=active]:bg-red-600 data-[state=active]:text-white"
            >
              <MessageCircle className="w-4 h-4" />
              Messages
            </TabsTrigger>
            <TabsTrigger 
              value="worksheets"
              className="flex items-center gap-2 text-red-100 data-[state=active]:bg-red-600 data-[state=active]:text-white"
            >
              <FileText className="w-4 h-4" />
              PDF Books
            </TabsTrigger>
            <TabsTrigger 
              value="mood"
              className="flex items-center gap-2 text-red-100 data-[state=active]:bg-red-600 data-[state=active]:text-white"
            >
              <BarChart3 className="w-4 h-4" />
              Mood
            </TabsTrigger>
            <TabsTrigger 
              value="resources"
              className="flex items-center gap-2 text-red-100 data-[state=active]:bg-red-600 data-[state=active]:text-white"
            >
              <BookOpen className="w-4 h-4" />
              Resources
            </TabsTrigger>
          </TabsList>

          <TabsContent value="messages" className="mt-0">
            <MessagingPanel />
          </TabsContent>

          <TabsContent value="worksheets" className="mt-0">
            <WorksheetPanel />
          </TabsContent>

          <TabsContent value="mood" className="mt-0">
            <MoodTracker />
          </TabsContent>

          <TabsContent value="resources" className="mt-0">
            <ResourceLibrary />
          </TabsContent>
        </Tabs>

        <Card className="mt-6 bg-black/60 backdrop-blur-sm border-red-500">
          <CardContent className="p-4 text-center">
            <p className="text-sm text-red-100 flex items-center justify-center gap-2">
              <Shield className="w-4 h-4 text-red-400" />
              All data is encrypted and secure for your privacy
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AppLayout;