import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { Share2, Copy, QrCode, Mail, MessageCircle } from 'lucide-react';

export const ShareApp: React.FC = () => {
  const [customMessage, setCustomMessage] = useState('');
  const appUrl = window.location.origin;
  
  const defaultMessage = `Hi! I'd like to invite you to use SecureSpace, a private mental health platform where you can message me securely. Each user has their own private account and messages are completely confidential. Access it here: ${appUrl}`;

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success('Copied to clipboard!');
    } catch (error) {
      toast.error('Failed to copy');
    }
  };

  const shareViaEmail = () => {
    const subject = 'Invitation to SecureSpace Mental Health Platform';
    const body = customMessage || defaultMessage;
    const mailtoUrl = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.open(mailtoUrl);
  };

  const shareViaSMS = () => {
    const message = customMessage || defaultMessage;
    const smsUrl = `sms:?body=${encodeURIComponent(message)}`;
    window.open(smsUrl);
  };

  const generateQRCode = () => {
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(appUrl)}`;
    window.open(qrUrl, '_blank');
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-900 border-red-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-400">
            <Share2 className="w-5 h-5" />
            Share Your App
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm text-gray-300 mb-2 block">App URL:</label>
            <div className="flex gap-2">
              <Input 
                value={appUrl} 
                readOnly 
                className="bg-gray-800 border-red-700 text-gray-200"
              />
              <Button 
                onClick={() => copyToClipboard(appUrl)}
                variant="outline"
                className="bg-red-900/20 border-red-700 text-red-300 hover:bg-red-900/40"
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div>
            <label className="text-sm text-gray-300 mb-2 block">Custom Message (Optional):</label>
            <textarea 
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              placeholder={defaultMessage}
              className="w-full p-3 bg-gray-800 border border-red-700 rounded text-gray-200 placeholder-gray-400 min-h-[100px]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Button 
              onClick={shareViaEmail}
              className="bg-blue-800 hover:bg-blue-700 text-white"
            >
              <Mail className="w-4 h-4 mr-2" />
              Email
            </Button>
            <Button 
              onClick={shareViaSMS}
              className="bg-green-800 hover:bg-green-700 text-white"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              SMS
            </Button>
            <Button 
              onClick={generateQRCode}
              className="bg-purple-800 hover:bg-purple-700 text-white"
            >
              <QrCode className="w-4 h-4 mr-2" />
              QR Code
            </Button>
            <Button 
              onClick={() => copyToClipboard(customMessage || defaultMessage)}
              variant="outline"
              className="bg-red-900/20 border-red-700 text-red-300 hover:bg-red-900/40"
            >
              <Copy className="w-4 h-4 mr-2" />
              Copy Message
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gray-900 border-red-800">
        <CardHeader>
          <CardTitle className="text-red-400">Instructions for Clients</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-gray-300 text-sm">
            <div className="flex items-start gap-3">
              <span className="bg-red-800 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">1</span>
              <p>Click the link or visit the URL</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="bg-red-800 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">2</span>
              <p>Enter their phone number for secure access</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="bg-red-800 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">3</span>
              <p>Use verification code: <code className="bg-gray-800 px-2 py-1 rounded">123456</code></p>
            </div>
            <div className="flex items-start gap-3">
              <span className="bg-red-800 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">4</span>
              <p>Start messaging securely - their messages are private and isolated</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};