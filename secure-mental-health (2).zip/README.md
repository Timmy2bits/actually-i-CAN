# SecureSpace - Mental Health Companion

A secure mental health platform for private messaging and resource sharing.

## 🚀 QUICK DEPLOYMENT GUIDE

### Step 1: Deploy to Vercel (Easiest)
1. Go to [vercel.com](https://vercel.com) and sign up
2. Click "New Project" 
3. Import from Git (connect your GitHub repo)
4. Click "Deploy" - Vercel will build and deploy automatically
5. **Your app URL will be: `https://your-project-name.vercel.app`**

### Step 2: Deploy to Netlify (Alternative)
1. Go to [netlify.com](https://netlify.com) and sign up
2. Drag and drop your project folder to deploy
3. **Your app URL will be: `https://your-project-name.netlify.app`**

## 📱 SHARING THE APP WITH CLIENTS

### Method 1: Built-in App Sharing (RECOMMENDED)
1. Open your deployed app
2. Log in as admin (use your phone number)
3. Click the "Share App" tab
4. Choose from:
   - **Email**: Send invitation emails
   - **SMS**: Send text message invites
   - **QR Code**: Generate QR code for easy sharing
   - **Direct Link**: Copy and paste the URL

### Method 2: Manual Sharing
Share your app URL directly:
- Text: "Download our secure mental health app: [YOUR-APP-URL]"
- Email: Include the URL in your communications
- Business cards: Print the URL
- Social media: Post the link

## 🔐 PRIVACY & SECURITY

- **Isolated Accounts**: Each phone number = unique private account
- **Private Messages**: Users only see their own conversations
- **Secure Auth**: Phone verification (demo code: 123456)
- **Admin Access**: View all messages via admin panel

## 👥 USER EXPERIENCE

### For Clients:
1. Visit your app URL
2. Enter phone number
3. Enter code: 123456
4. Start secure messaging
5. Upload PDFs, track mood, access resources

### For You (Admin):
1. Log in with your phone number
2. Access "Admin Panel" tab
3. View all user messages and statistics
4. Use "Share App" tab to invite new clients

## 📊 MANAGING USERS

### View All Messages:
- Use the Admin Panel in your app
- Or login to [Supabase Dashboard](https://supabase.com/dashboard)
- Go to Table Editor > messages
- Each user_id represents a unique client

### User Privacy:
- Users cannot see each other's messages
- Each conversation is completely isolated
- Only you (admin) can view all messages

## 🛠 TECHNICAL SETUP

### Environment Variables (Already Configured):
- Supabase URL and API keys are embedded
- SMS verification system is active
- Database tables are created and secured

### Database Structure:
- **users**: Phone numbers and user IDs
- **messages**: All conversations (isolated by user_id)
- **RLS enabled**: Row Level Security for privacy

## 📞 NEXT STEPS

1. **Deploy Now**: Choose Vercel or Netlify above
2. **Test the App**: Visit your deployed URL
3. **Share with Clients**: Use the built-in sharing features
4. **Monitor Usage**: Check admin panel for messages

## 🆘 SUPPORT

- Website: https://www.twelch.com/
- Blog: https://addiction--recovery.blogspot.com/?m=1

---

**Your app is ready to deploy and share! The email, SMS, and QR code features are built into the app itself - just deploy and use the "Share App" tab.**